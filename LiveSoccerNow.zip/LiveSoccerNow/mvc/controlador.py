# Imports
import modelos
from equipos import get_equipos
from partidos import get_partidos
from wsgiref.simple_server import make_server
import vistas
from datetime import datetime
import hashlib
from collections import defaultdict

# ----------------------------------------------------- REGISTER Y LOGIN
# Registrar un nuevo Usuario en nuestra BBDD
def insertar_usuario(nombre, correo, contrasena):
    sesion = modelos.abrir_sesion()
    try:
        contrasena_encriptada = encriptar_contrasena(contrasena)
        nuevo_usuario = modelos.Usuario(nombre=nombre, correo=correo, contrasena=contrasena_encriptada)
        nuevo_usuario.create(sesion)
        print("Usuario registrado con éxito!")
    except Exception as e:
        print("Error al registrar el usuario:", e)
    finally:
        sesion.close()

# Compobrar que el Usuario existe en nuestra BBDD
def iniciar_sesion(correo, contrasena):
    sesion = modelos.abrir_sesion()
    try:
        usuario = sesion.query(modelos.Usuario).filter_by(correo=correo).first()
        if usuario:
            contrasena_encriptada = encriptar_contrasena(contrasena)
            if usuario.contrasena == contrasena_encriptada:
                print("Inicio de sesión exitoso.")
            else:
                print("contrasena incorrecta.")
        else:
            print("Correo no encontrado en la base de datos.")
    except Exception as e:
        print("Error al iniciar sesión:", e)
    finally:
        sesion.close()

# Probar register y login
    def probar_register():
        nombre = input("Ingrese su nombre: ")
        correo = input("Ingrese su correo electrónico: ")
        contrasena = input("Ingrese su contrasena: ")
        insertar_usuario(nombre, correo, contrasena)
    def probar_login():
        correo_inicio = input("Ingrese su correo electrónico para iniciar sesión: ")
        contrasena_inicio = input("Ingrese su contrasena: ")
        iniciar_sesion(correo_inicio, contrasena_inicio)

# Encriptar contrasena con sha256
def encriptar_contrasena(contrasena):
    return hashlib.sha256(contrasena.encode()).hexdigest()
# ----------------------------------------------------- FIN REGISTER Y LOGIN

# ----------------------------------------------------- EQUIPOS
# Insertar Equipos Obtenidos de la API en nuestra BBDD
def insertar_equipos():
    sesion2 = modelos.abrir_sesion()
    equipos_API = get_equipos() # Función de obtener los equipos de la API en equipos.py
    try:
        for equipo in equipos_API:
            equipo_nombre = equipo['name']
            equipo_icon_url = equipo['icon_url']
            equipo = modelos.Equipo(nombre=equipo_nombre, icono=equipo_icon_url)
            equipo.create(sesion2)
    except Exception as e:
        print("Error al insertar equipos:", e)
        sesion2.rollback()
    finally:
        modelos.cerrar_sesion(sesion2)
# ----------------------------------------------------- FIN EQUIPOS

# ----------------------------------------------------- PARTIDOS Y GOLES (TODA LA INFO)
# Insertar todos los Partidos Obtenidos de la API en nuestra BBDD
def insertar_partidos(jornada):
    sesion = modelos.abrir_sesion()
    partidosAPI = get_partidos(jornada) # Función de obtener los partidos de la API en partidos.py
    try:
        # Guardar información de los Partidos en nuestra BBDD
        for partido_info in partidosAPI:
            equipo_local = sesion.query(modelos.Equipo).filter_by(nombre=partido_info["equipo1"]["nombre"]).first()
            equipo_visitante = sesion.query(modelos.Equipo).filter_by(nombre=partido_info["equipo2"]["nombre"]).first()             
            partido = modelos.Partido(
                idEquipoLocal=equipo_local.idEquipo,
                idEquipoVisitante=equipo_visitante.idEquipo,
                fecha=partido_info["fecha_hora"],
                jornada=int(jornada),
            )
            if partido_info["finalizado"]:
                partido.puntuacion_equipo_local = partido_info['puntos_equipo1']
                partido.puntuacion_equipo_visitante = partido_info['puntos_equipo2']
            
            partido.create(sesion)
            if partido_info["finalizado"]:
                # Guardar información de los Goles de cada Partido en nuestra BBDD
                goles_ordenados = sorted(partido_info['goles'], key=lambda x: x['minute']) # Ordenar los goles cronológicamente
                for gol_info in goles_ordenados:
                    # Obtener todos los goles del partido actual
                    goles_partido = sesion.query(modelos.Gol).filter_by(idPartido=partido.idPartido).all()
                    # Determinar de qué equipo ha sido el gol
                    score_team1 = sum(1 for gol_partido in goles_partido if gol_partido.idEquipo == partido.idEquipoLocal)
                    if gol_info['scoreTeam1'] == score_team1 + 1:
                        equipo_gol_id = partido.idEquipoLocal
                    else:
                        equipo_gol_id = partido.idEquipoVisitante
                    # Guardar la información del gol actual
                    gol = modelos.Gol(
                        idPartido=partido.idPartido,
                        idEquipo=equipo_gol_id,
                        jugador=gol_info['goal_getter_name'],
                        minuto=gol_info['minute'],
                        comment=gol_info['comment'],
                        isPenalty=gol_info['is_penalty'],
                        isOwnGoal=gol_info['is_own_goal']
                    )
                    gol.create(sesion)
    except Exception as e:
        print(f"Error al guardar datos en la base de datos: {e}")
        # Si ocurre un error, deshacer la sesión
        sesion.rollback()
    finally:
        # Cerrar la sesión
        modelos.cerrar_sesion(sesion)
# ----------------------------------------------------- FIN PARTIDOS Y GOLES (TODA LA INFO)

# ----------------------------------------------------- OBTENER ÚLTIMOS 8 PARTIDOS DESDE LA BBDD
def get_ultimos_partidos():
    # Obtener últimos 8 partidos jugados con sus goles
    fecha_actual = datetime.now()
    #print("Fecha actual:", fecha_actual)
    #print("Type Fecha actual:", type(fecha_actual))
    sesion = modelos.abrir_sesion()
    # Consulta para obtener los últimos 8 partidos jugados
    partidos = (
        modelos.Partido.read(sesion)
        .filter(modelos.Partido.fecha <= fecha_actual)
        .order_by(modelos.Partido.fecha.desc())
        .limit(8)
    )
    # Crear una lista para almacenar los 8 últimos partidos
    ultimos_partidos = []
    # Asociar los goles a cada partido que le corresponde
    for partido in partidos.all():
        #print("Partido.fecha",partido.fecha)
        #print("TYPE:", type(partido.fecha))
        # Obtenemos todos los goles asociados a cada partido
        goles = (
            modelos.Gol.read(sesion)
            .filter(modelos.Gol.idPartido == partido.idPartido)
        )
        # Guardamos los datos de cada gol en una lista
        lista_goles = [
            {"jugador": gol.jugador, "equipo":gol.idEquipo, "minuto": gol.minuto, "comment":gol.comment, "isPenalty":gol.isPenalty, "isOwnGoal":gol.isOwnGoal} for gol in goles.all()]
        # Fecha y hora
        fecha_partido = partido.fecha
        fecha_formateada = fecha_partido.strftime('%d/%m/%Y')
        hora_formateada = fecha_partido.strftime('%H:%M')
        # print(fecha_formateada)
        # print(hora_formateada)
        
        # Agregamos la lista de goles al partido
        partido_info = {
            "idPartido": partido.idPartido,
            "fecha": fecha_formateada,
            "hora": hora_formateada,
            "equipo_local": partido.equipo_local,
            "equipo_visitante": partido.equipo_visitante,
            "id_equipo_local": partido.idEquipoLocal,
            "id_equipo_visitante": partido.idEquipoVisitante,
            "puntuacion_equipo_local": partido.puntuacion_equipo_local,
            "puntuacion_equipo_visitante": partido.puntuacion_equipo_visitante,
            "goles": lista_goles  # Agregar la lista de goles al partido
        }
        # Agregar el partido a la lista de los 8 últimos partidos
        ultimos_partidos.append(partido_info)

    modelos.cerrar_sesion(sesion)
    sesion = None
    return ultimos_partidos
    #print("Partidos con Goles:", ultimos_partidos)
# ----------------------------------------------------- FIN OBTENER ÚLTIMOS 8 PARTIDOS DESDE LA BBDD

# ----------------------------------------------------- OBTENER TODOS LOS PARTIDOS DESDE LA BBDD
def get_todos_los_partidos():
    sesion = modelos.abrir_sesion()

    # Consulta para obtener todos los partidos
    partidos = (
        modelos.Partido.read(sesion)
        .order_by(modelos.Partido.fecha.asc())
        .all()
    )

    # Crear un diccionario para almacenar los partidos por jornada
    partidos_por_jornada = defaultdict(list)

    # Iterar sobre cada partido y agregarlo al diccionario por jornada
    for partido in partidos:
        # Obtener todos los goles asociados a cada partido
        goles = (
            modelos.Gol.read(sesion)
            .filter(modelos.Gol.idPartido == partido.idPartido)
        )

        # Guardar los datos de cada gol en una lista
        lista_goles = [
            {
                "jugador": gol.jugador,
                "equipo": gol.idEquipo,
                "minuto": gol.minuto,
                "comment": gol.comment,
                "isPenalty": gol.isPenalty,
                "isOwnGoal": gol.isOwnGoal
            } for gol in goles.all()
        ]

        # Fecha y hora formateadas
        fecha_partido = partido.fecha
        fecha_formateada = fecha_partido.strftime('%d/%m/%Y')
        hora_formateada = fecha_partido.strftime('%H:%M')

        # Agregar la lista de goles al partido
        partido_info = {
            "idPartido": partido.idPartido,
            "fecha": fecha_formateada,
            "hora": hora_formateada,
            "equipo_local": partido.equipo_local,
            "equipo_visitante": partido.equipo_visitante,
            "id_equipo_local": partido.idEquipoLocal,
            "id_equipo_visitante": partido.idEquipoVisitante,
            "puntuacion_equipo_local": partido.puntuacion_equipo_local,
            "puntuacion_equipo_visitante": partido.puntuacion_equipo_visitante,
            "goles": lista_goles  # Agregar la lista de goles al partido
        }

        # Agrupar por jornada
        partidos_por_jornada[partido.jornada].append(partido_info)

    partidos_por_jornada = dict(sorted(partidos_por_jornada.items()))
    modelos.cerrar_sesion(sesion)
    sesion = None
    return partidos_por_jornada
# ----------------------------------------------------- FIN OBTENER TODOS LOS PARTIDOS DESDE LA BBDD

# ----------------------------------------------------- OBTENER SIGUIENTES 8 PARTIDOS DESDE LA BBDD
def get_siguientes_partidos():
    sesion = modelos.abrir_sesion()

    try:
        fecha_actual = datetime.now()

        # Consulta para obtener los siguientes partidos no finalizados
        partidos = (
            modelos.Partido.read(sesion)
            .filter(modelos.Partido.fecha > fecha_actual)
            .filter(modelos.Partido.puntuacion_equipo_local == None)
            .order_by(modelos.Partido.fecha)
            .limit(8)
            .all()
        )

        # Crear una lista para almacenar los siguientes partidos
        siguientes_partidos = []

        # Iterar sobre cada partido y obtener información
        for partido in partidos:
            # Obtener todos los goles asociados a cada partido
            goles = (
                modelos.Gol.read(sesion)
                .filter(modelos.Gol.idPartido == partido.idPartido)
            )

            # Guardar los datos de cada gol en una lista
            lista_goles = [
                {
                    "jugador": gol.jugador,
                    "equipo": gol.idEquipo,
                    "minuto": gol.minuto,
                    "comment": gol.comment,
                    "isPenalty": gol.isPenalty,
                    "isOwnGoal": gol.isOwnGoal
                } for gol in goles.all()
            ]

            # Fecha y hora formateadas
            fecha_partido = partido.fecha
            fecha_formateada = fecha_partido.strftime('%d/%m/%Y')
            hora_formateada = fecha_partido.strftime('%H:%M')

            # Agregar la lista de goles al partido
            partido_info = {
                "idPartido": partido.idPartido,
                "fecha": fecha_formateada,
                "hora": hora_formateada,
                "equipo_local": partido.equipo_local,
                "equipo_visitante": partido.equipo_visitante,
                "id_equipo_local": partido.idEquipoLocal,
                "id_equipo_visitante": partido.idEquipoVisitante,
                "puntuacion_equipo_local": partido.puntuacion_equipo_local,
                "puntuacion_equipo_visitante": partido.puntuacion_equipo_visitante,
                "goles": lista_goles  # Agregar la lista de goles al partido
            }

            # Agregar el partido a la lista de siguientes partidos
            siguientes_partidos.append(partido_info)

    except Exception as e:
        print(f"Error al obtener siguientes partidos: {e}")
    finally:
        # Cerrar la sesión
        modelos.cerrar_sesion(sesion)

    return siguientes_partidos
# ----------------------------------------------------- FIN OBTENER SIGUIENTES 8 PARTIDOS DESDE LA BBDD

# ----------------------------------------------------- OBTENER EQUIPOS DESDE LA BBDD
def get_equipos_bbdd():
    try:
        sesion = modelos.abrir_sesion()
        # Consulta para obtener los nombres de los equipos
        equipos = modelos.Equipo.read(sesion).all()
        return equipos
    except Exception as e:
        print(f"Error al obtener equipos desde la base de datos: {e}")
    finally:
        modelos.cerrar_sesion(sesion)
# ----------------------------------------------------- FIN OBTENER EQUIPOS DESDE LA BBDD

# ----------------------------------------------------- APP DE RENDERIZADO

# Definir la función app que manejará las solicitudes.
def app(environ, start_response):
    path = environ.get('PATH_INFO')
    # print('path: ', path)
    # Páginas
    if path == '/home' or path == '/':
        return vistas.home_handle_index(environ, start_response, ultimos_partidos, siguientes_partidos)
    elif path == '/resultados':
        return vistas.results_handle_index(environ, start_response, partidos_por_jornada)
    elif path == '/mis-equipos':
        return vistas.myteams_handle_index(environ, start_response, todos_los_equipos)
    elif path == '/noticias':
        return vistas.news_handle_index(environ, start_response, ultimos_partidos)
    elif path == '/inicio-sesion':
        return vistas.login_handle_index(environ, start_response, ultimos_partidos)
    # Recursos
    elif   path.startswith('/static/'):
        return vistas.serve_static(environ, start_response)
    elif path.startswith('/assets/'):
        return vistas.handel_images(environ, start_response)
    else:
        return vistas.handle_404(environ, start_response)
# ----------------------------------------------------- FIN APP DE RENDERIZADO

if __name__ == "__main__":
    #'''
    # Insertar la información de los Equipos
    insertar_equipos()

    # Insertar los partidos de cada jornada, 6 en total
    for jornada in range(1, 7):
        insertar_partidos(str(jornada))
    #'''
    # Obtener últimos partidos desde la BBDD
    ultimos_partidos = get_ultimos_partidos()
    # Obtener TODOS los partidos desde la BBDD
    partidos_por_jornada = get_todos_los_partidos()
    # Obtener los siguientes partidos desde la BBDD
    siguientes_partidos = get_siguientes_partidos()
    # Obtener todos los equipos desde la BBSS
    todos_los_equipos = get_equipos_bbdd()

    # Abrir el servidor
    host = 'localhost'
    port = 8000
    httpd = make_server(host, port, app)
    print(f"Servidor en http://{host}:{port}")
    httpd.serve_forever()

    #probar_register()
    #probar_login()
'''
Una vez ejecutado el controlador, podemos acceder a través del navegador, 
con las rutas: http://localhost:8000/    (no se usa jinja2)
y   http://localhost:8000/es, esta segunda usa jinja2.
Con la url http://localhost:8000/static/ se mostrará el archivo css.
Si se pone una url diferente, saldrá el mensaje de 'página no encontrada'
'''