import requests
import json
def get_partidos(jornada):
    url = "https://api.openligadb.de/getmatchdata/champion1/2023/"
    response = requests.get(url + jornada)

    if response.status_code == 200:
        data = response.json()

        # Lista para almacenar la información de los partidos
        partidos_info = []

        for match in data:
            match_finished = match["matchIsFinished"]
            match_date_time = match["matchDateTime"]
            team1_name = match["team1"]["teamName"]
            team2_name = match["team2"]["teamName"]
            team1_icon_url = match["team1"]["teamIconUrl"]
            team2_icon_url = match["team2"]["teamIconUrl"]

            if match_finished:
                match_results = match["matchResults"]
                goals = match["goals"]

                all_goals = []

                for goal in goals:

                    minute = goal["matchMinute"]
                    scoreTeam1 = goal["scoreTeam1"]
                    scoreTeam2 = goal["scoreTeam2"]
                    goal_getter_name = goal["goalGetterName"]
                    comment = goal["comment"]
                    is_penalty = goal["isPenalty"]
                    is_own_goal = goal["isOwnGoal"]

                    goal_info = {
                        "minute": minute,
                        "scoreTeam1": scoreTeam1,
                        "scoreTeam2": scoreTeam2,
                        "goal_getter_name": goal_getter_name,
                        "comment": comment,
                        "is_penalty": is_penalty,
                        "is_own_goal": is_own_goal
                    }

                    all_goals.append(goal_info)

                for result in match_results:
                    points_team1 = result["pointsTeam1"]
                    points_team2 = result["pointsTeam2"]

                partido_info = {
                    "fecha_hora": match_date_time,
                    "equipo1": {
                        "nombre": team1_name,
                        "icono": team1_icon_url
                    },
                    "equipo2": {
                        "nombre": team2_name,
                        "icono": team2_icon_url
                    },
                    "finalizado": match_finished,
                    "puntos_equipo1": points_team1,
                    "puntos_equipo2": points_team2,
                    "goles": all_goals
                }

                partidos_info.append(partido_info)
            else:
                partido_info = {
                    "fecha_hora": match_date_time,
                    "equipo1": {
                        "nombre": team1_name,
                        "icono": team1_icon_url
                    },
                    "equipo2": {
                        "nombre": team2_name,
                        "icono": team2_icon_url
                    },
                    "finalizado": match_finished
                }

                partidos_info.append(partido_info)

        return partidos_info
    else:
        return []

if __name__ == "__main__":
    partidos = get_partidos("6")
    partidos_json = json.dumps(partidos, indent=2)
    print(partidos_json)