import requests
from sqlalchemy import create_engine, Column, Integer, String, ForeignKey
from sqlalchemy.orm import sessionmaker, declarative_base

# Configurar la conexión a la base de datos 
db_url = "postgresql://postgres:efren@localhost/livesoccernow_db"  
engine = create_engine(db_url)

# Definir una clase para la tabla de favoritos
Base = declarative_base()
class Favorito(Base):
    __tablename__ = 'favoritos'

    idFavorito = Column(Integer, primary_key=True)
    idUsuario = Column(Integer, ForeignKey('usuarios.idUsuario'))
    idEquipo = Column(Integer, ForeignKey('equipos.idEquipo'))

# Archivo de texto para almacenar equipos favoritos
archivo_favoritos = "equipos_favoritos.txt"

# Función para cargar equipos favoritos desde el archivo
def cargar_equipos_favoritos():
    try:
        with open(archivo_favoritos, "r") as file:
            return [line.strip() for line in file]
    except FileNotFoundError:
        return []

# Función para obtener equipos de la API
def get_equipos():
    api_url = "https://api.openligadb.de/getmatchdata/champion1/2023/1"
    response = requests.get(api_url)

    if response.status_code == 200:
        data = response.json()
        team_list = []

        for match in data[:16]:
            team1 = match['team1']
            teamName1 = team1.get('teamName', 'No teamName disponible')

            team2 = match['team2']
            teamName2 = team2.get('teamName', 'No teamName disponible')

            team_list.append(teamName1)
            team_list.append(teamName2)

        return team_list
    else:
        return []

def guardar_equipos_favoritos(equipos_favoritos):
    with open(archivo_favoritos, "w") as file:
        for equipo in equipos_favoritos:
            file.write(equipo + "\n")
            
# Función para agregar un equipo a favoritos y a la base de datos
def agregar_a_favoritos(equipo, equipos_favoritos, session):
    if equipo not in equipos_favoritos:
        equipos_favoritos.append(equipo)
        print(f"{equipo} ha sido añadido a tus equipos favoritos.")
        guardar_equipos_favoritos(equipos_favoritos)
        

    else:
        print(f"{equipo} ya está en tus equipos favoritos.")

# Función para eliminar un equipo de favoritos y de la base de datos
def eliminar_de_favoritos(equipo, equipos_favoritos, session):
    if equipo in equipos_favoritos:
        equipos_favoritos.remove(equipo)
        print(f"{equipo} ha sido eliminado de tus equipos favoritos.")
        guardar_equipos_favoritos(equipos_favoritos)
        
    else:
        print(f"{equipo} no está en tus equipos favoritos.")

if __name__ == "__main__":
    # Crear la tabla de favoritos en la base de datos
    Base.metadata.create_all(engine)

    # Crear una sesión de SQLAlchemy
    Session = sessionmaker(bind=engine)
    session = Session()

    equipos_favoritos = cargar_equipos_favoritos()
    lista_equipos = get_equipos()

    for idx, team in enumerate(lista_equipos, start=1):
        if team in equipos_favoritos:
            print(f"Equipo {idx}: {team} (Favorito)")
        else:
            print(f"Equipo {idx}: {team} (No en favoritos)")

    while True:
        opcion = input("¿Deseas agregar o eliminar un equipo de tus favoritos? (A/E/N): ")
        if opcion.lower() == "a":
            indice_equipo = int(input("Ingresa el número de equipo que deseas agregar a favoritos: "))
            if 1 <= indice_equipo <= len(lista_equipos):
                equipo_favorito = lista_equipos[indice_equipo - 1]
                agregar_a_favoritos(equipo_favorito, equipos_favoritos, session)
            else:
                print("Índice de equipo no válido. Inténtalo de nuevo.")
        elif opcion.lower() == "e":
            equipo_eliminar = input("Ingresa el nombre del equipo que deseas eliminar de favoritos: ")
            eliminar_de_favoritos(equipo_eliminar, equipos_favoritos, session)
        elif opcion.lower() == "n":
            session.commit()  
            session.close()   
            break
        else:
            print("Opción no válida. Inténtalo de nuevo.")