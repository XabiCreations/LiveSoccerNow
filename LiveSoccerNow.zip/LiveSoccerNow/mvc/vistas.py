from jinja2 import Environment, FileSystemLoader
import os

env = Environment(loader=FileSystemLoader('Ej_mvc/templates'))
template = env.get_template('index.html')
template_results = env.get_template('resultados.html')
template_myteams = env.get_template('mis-equipos.html')
template_news = env.get_template('noticias.html')
template_login = env.get_template('inicio-sesion.html')

# Funciones para manejar las rutas específicas
# HOME
def home_handle_index(environ, start_response, partidos_con_goles, siguientes_partidos):
    # Lógica para la ruta '/home'
    response = template.render(partidos_con_goles=partidos_con_goles, siguientes_partidos=siguientes_partidos).encode('utf-8')
    # print("PARTIDOS(VISTAS)", todos_los_partidos)
    status = '200 OK'
    response_headers = [('Content-type', 'text/html')]
    start_response(status, response_headers)
    return [response]

# RESULTADOS
def results_handle_index(environ, start_response, partidos_por_jornada):
    # Lógica para la ruta '/resultados'
    response = template_results.render(partidos_por_jornada=partidos_por_jornada).encode('utf-8')
    #print("PARTIDOS(VISTAS)",partidos_con_goles)
    status = '200 OK'
    response_headers = [('Content-type', 'text/html')]
    start_response(status, response_headers)
    return [response]

# MIS EQUIPOS
def myteams_handle_index(environ, start_response, todos_los_equipos):
    # Lógica para la ruta '/mis-equipos'
    response = template_myteams.render(todos_los_equipos=todos_los_equipos).encode('utf-8')
    #print("PARTIDOS(VISTAS)",partidos_con_goles)
    status = '200 OK'
    response_headers = [('Content-type', 'text/html')]
    start_response(status, response_headers)
    return [response]

# NOTICIAS
def news_handle_index(environ, start_response, noticias):
    # Lógica para la ruta '/noticias'
    response = template_news.render(noticias=noticias).encode('utf-8')
    #print("PARTIDOS(VISTAS)",partidos_con_goles)
    status = '200 OK'
    response_headers = [('Content-type', 'text/html')]
    start_response(status, response_headers)
    return [response]

# LOGIN
def login_handle_index(environ, start_response, login):
    # Lógica para la ruta '/iniciar-sesion'
    response = template_login.render(login=login).encode('utf-8')
    #print("PARTIDOS(VISTAS)",partidos_con_goles)
    status = '200 OK'
    response_headers = [('Content-type', 'text/html')]
    start_response(status, response_headers)
    # return [b'Hola, Mundo en Espanol!']
    return [response]


def handle_404(environ, start_response):
    # Lógica para manejar una ruta no reconocida (404)
    status = '404 Not Found'
    response_headers = [('Content-type', 'text/html')]
    start_response(status, response_headers)
    return [b'Pagina no encontrada']

def handel_images(environ, start_response):
    static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'assets'))
    path = environ['PATH_INFO']
    #print(path)
    path2 = path.replace("/assets", "")
    images_path = static_dir + path2
    if not path.startswith('/assets/'):
        start_response('404 Not Found', [('Content-type', 'text/plain')])
        return [b'Not Found']
    else:
        # Serve the file
        try:
            with open(images_path, 'rb') as file:
                imgFile = file.read()
                start_response('200 OK', [('Content-type', 'text/css')]) 
                return [imgFile]            
        except Exception as e:
            start_response('500 Internal Server Error', [('Content-type', 'text/plain')])
            return [str(e).encode('utf-8')]

# Función para servir archivos estáticos
def serve_static(environ, start_response):
    # static_dir = './static'  
    static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'static'))
    # print('static_dir', static_dir)
    path = environ['PATH_INFO']
    #css_path = 'e:/Proyectos_Python/Ej_mvc/static/style.css'
    css_path = static_dir + '/estilos-colores.css'
    
    # print('css_path:', css_path)
    # print('os.path', os.path)
    if not path.startswith('/static/'):
        start_response('404 Not Found', [('Content-type', 'text/plain')])
        return [b'Not Found']
    else:
        # Serve the file
        try:
            with open(css_path, 'rb') as file:
                cssFile = file.read()
                start_response('200 OK', [('Content-type', 'text/css')]) 
                return [cssFile]            
        except Exception as e:
            start_response('500 Internal Server Error', [('Content-type', 'text/plain')])
            return [str(e).encode('utf-8')]