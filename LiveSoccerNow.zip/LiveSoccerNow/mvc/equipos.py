import requests
import json

def get_equipos():
    api_url = "https://api.openligadb.de/getmatchdata/champion1/2023/1"
    response = requests.get(api_url)

    if response.status_code == 200:
        data = response.json()
        team_list = []

        for match in data[:16]:
            team1 = match['team1']
            teamName1 = team1.get('teamName', 'No teamName disponible')
            team1_icon_url = team1.get('teamIconUrl', 'URL del ícono no disponible')

            team2 = match['team2']
            teamName2 = team2.get('teamName', 'No teamName disponible')
            team2_icon_url = team2.get('teamIconUrl', 'URL del ícono no disponible')

            team_list.append({'name': teamName1, 'icon_url': team1_icon_url})
            team_list.append({'name': teamName2, 'icon_url': team2_icon_url})

        return team_list
    else:
        return []

if __name__ == "__main__":
    lista_equipos = get_equipos()
    equipos_json = json.dumps(lista_equipos, indent=2)
    print(equipos_json)
