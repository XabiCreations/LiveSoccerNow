from sqlalchemy import create_engine, Column, Integer, String, DateTime, Boolean
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import declarative_base
from sqlalchemy import ForeignKey
from sqlalchemy.orm import relationship

# Configurar la conexión a la base de datos PostgreSQL
engine = create_engine('postgresql://postgres:efren@localhost/livesoccernow_db')

# Crear una sesión para interactuar con la base de datos
Session = sessionmaker(bind=engine)

def abrir_sesion():
    return Session()

def cerrar_sesion(session):
    # Cerrar la sesión al terminar
    session.close()

class miCRUD:
    def create(self, session):
        session.add(self)
        session.commit()

    @classmethod
    def read(cls, session, **consulta):
        query = session.query(cls)
        if consulta:
            query = query.filter_by(**consulta)
        return query

    def update(self, session):
        session.commit()

    def delete(self, session):
        session.delete(self)
        session.commit()

Base = declarative_base()

class Usuario(Base, miCRUD):
    __tablename__ = 'usuarios'
    idUsuario = Column(Integer, primary_key=True, autoincrement=True)
    nombre = Column(String, nullable=False)
    correo = Column(String, nullable=False)
    contrasena = Column(String, nullable=False)

class Equipo(Base, miCRUD):
    __tablename__ = 'equipos'
    idEquipo = Column(Integer, primary_key=True, autoincrement=True)
    nombre = Column(String, nullable=False)
    icono = Column(String, nullable=False)

class Partido(Base, miCRUD):
    __tablename__ = 'partidos'
    idPartido = Column(Integer, primary_key=True, autoincrement=True)
    idEquipoLocal = Column(Integer, ForeignKey('equipos.idEquipo'), nullable=False)
    idEquipoVisitante = Column(Integer, ForeignKey('equipos.idEquipo'), nullable=False)
    equipo_local = relationship("Equipo", foreign_keys=[idEquipoLocal])
    equipo_visitante = relationship("Equipo", foreign_keys=[idEquipoVisitante])
    puntuacion_equipo_local = Column(Integer)
    puntuacion_equipo_visitante = Column(Integer)
    fecha = Column(DateTime, nullable=False)
    jornada = Column(Integer, nullable=False)
    canal = Column(String)

class Favorito(Base, miCRUD):
    __tablename__ = 'favoritos'
    idFavorito = Column(Integer, primary_key=True, autoincrement=True)
    idUsuario = Column(Integer, ForeignKey('usuarios.idUsuario'), nullable=False)
    idEquipo = Column(Integer, ForeignKey('equipos.idEquipo'), nullable=False)

class Gol(Base, miCRUD):
    __tablename__ = 'goles'
    idGol = Column(Integer, primary_key=True, autoincrement=True)
    idPartido = Column(Integer, ForeignKey('partidos.idPartido'), nullable=False)
    idEquipo = Column(Integer, ForeignKey('equipos.idEquipo'), nullable=False)
    jugador = Column(String, nullable=False)
    minuto = Column(Integer, nullable=False)
    comment = Column(String)
    isPenalty = Column(Boolean)
    isOwnGoal = Column(Boolean)

# Crear todas las tablas en la base de datos
Base.metadata.create_all(engine)